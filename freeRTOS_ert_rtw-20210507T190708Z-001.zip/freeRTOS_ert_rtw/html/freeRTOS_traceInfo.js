function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "freeRTOS"};
	this.sidHashMap["freeRTOS"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "freeRTOS:6"};
	this.sidHashMap["freeRTOS:6"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<Root>/input"] = {sid: "freeRTOS:1"};
	this.sidHashMap["freeRTOS:1"] = {rtwname: "<Root>/input"};
	this.rtwnameHashMap["<Root>/Conversion"] = {sid: "freeRTOS:6"};
	this.sidHashMap["freeRTOS:6"] = {rtwname: "<Root>/Conversion"};
	this.rtwnameHashMap["<Root>/output"] = {sid: "freeRTOS:2"};
	this.sidHashMap["freeRTOS:2"] = {rtwname: "<Root>/output"};
	this.rtwnameHashMap["<S1>/input"] = {sid: "freeRTOS:7"};
	this.sidHashMap["freeRTOS:7"] = {rtwname: "<S1>/input"};
	this.rtwnameHashMap["<S1>/Divide"] = {sid: "freeRTOS:4"};
	this.sidHashMap["freeRTOS:4"] = {rtwname: "<S1>/Divide"};
	this.rtwnameHashMap["<S1>/Gain"] = {sid: "freeRTOS:3"};
	this.sidHashMap["freeRTOS:3"] = {rtwname: "<S1>/Gain"};
	this.rtwnameHashMap["<S1>/output"] = {sid: "freeRTOS:8"};
	this.sidHashMap["freeRTOS:8"] = {rtwname: "<S1>/output"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
