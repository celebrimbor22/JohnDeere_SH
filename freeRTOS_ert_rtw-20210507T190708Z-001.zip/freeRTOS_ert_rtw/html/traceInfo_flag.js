function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["freeRTOS.c:90c36"]=1;
    this.traceFlag["freeRTOS.c:96c58"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["freeRTOS.c:90"]=1;
    this.lineTraceFlag["freeRTOS.c:96"]=1;
    this.lineTraceFlag["freeRTOS.h:45"]=1;
    this.lineTraceFlag["freeRTOS.h:50"]=1;
    this.lineTraceFlag["freeRTOS.h:55"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
