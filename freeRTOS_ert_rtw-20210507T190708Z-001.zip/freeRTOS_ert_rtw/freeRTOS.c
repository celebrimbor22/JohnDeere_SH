/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: freeRTOS.c
 *
 * Code generated for Simulink model 'freeRTOS'.
 *
 * Model version                  : 1.2
 * Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
 * C/C++ source code generated on : Fri May  7 13:34:20 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives:
 *    1. Safety precaution
 *    2. Debugging
 * Validation result: Passed (7), Warnings (2), Error (0)
 */

#include "freeRTOS.h"
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFFFFFU) ) || ( INT_MAX != (0x7FFFFFFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFU) ) || ( LONG_MAX != (0x7FFFFFFF) )
#error Code was generated for compiler with different sized ulong/long. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

/* Block signals (default storage) */
B_freeRTOS_T freeRTOS_B;

/* External inputs (root inport signals with default storage) */
ExtU_freeRTOS_T freeRTOS_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_freeRTOS_T freeRTOS_Y;

/* Real-time model */
static RT_MODEL_freeRTOS_T freeRTOS_M_;
RT_MODEL_freeRTOS_T *const freeRTOS_M = &freeRTOS_M_;

/* Model step function */
void freeRTOS_step(void)
{
  /* Gain: '<S1>/Gain' incorporates:
   *  Inport: '<Root>/input'
   */
  freeRTOS_B.inputganacia = 38400U * freeRTOS_U.input;

  /* Outport: '<Root>/output' incorporates:
   *  Gain: '<S1>/Gain'
   *  Product: '<S1>/Divide'
   */
  freeRTOS_Y.output = (uint16_T)(freeRTOS_B.inputganacia >> 8);
}

/* Model initialize function */
void freeRTOS_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void freeRTOS_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
